# SQ4CDBirdyEggRestore

version 0.1 not fully tested

 Restores both software store easter eggs in the CD version of SQ4 and prevents lock up when triggering both at the same time.

INSTALLATION

Copy the rm397.src, rm397.view, and rm397.hep files into youre game folder.