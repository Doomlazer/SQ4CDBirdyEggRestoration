# SQ4CDBirdyEggRestore

version 0.2.1 

Fixed wrong view format. Not fully tested - the birdy script triggers without smelling wall right now

 Restores both software store easter eggs in the CD version of SQ4 and prevents lock up when triggering both at the same time.

INSTALLATION

Copy the 397.hep, 397.scr and 397.v56 files into your SQIV game folder.
